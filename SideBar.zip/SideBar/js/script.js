document.addEventListener("DOMContentLoaded", function() {
    const menuBtn = document.querySelector(".menu-btn");
    const sidebar = document.querySelector(".sidebar");

    // Menu button
    menuBtn.addEventListener("click", function() {
        sidebar.classList.add("active");
        menuBtn.style.visibility = "hidden";
    });

    // Close button
    const closeBtn = document.querySelector(".close-btn");
    closeBtn.addEventListener("click", function() {
        sidebar.classList.remove("active");
        menuBtn.style.visibility = "visible";
    });

    // Sub menu
    const subMenuBtns = document.querySelectorAll(".sub-btn");

    subMenuBtns.forEach((btn) => {
        btn.addEventListener("click", function(event) {
            event.preventDefault();

            const container = document.getElementById(this.dataset.container);

            if (!container.classList.contains("active")) {
                // Activate the sub-menu
                container.classList.add("active");
                container.style.height = "auto";
                const height = container.clientHeight + "px";
                container.style.height = "0px";
                setTimeout(function() {
                    container.style.height = height;
                }, 0);
                // Add rotate arrow
                this.querySelector(".dropdown").classList.add("rotate");
            } else {
                // Deactivate the sub-menu
                container.style.height = "0px";
                this.querySelector(".dropdown").classList.remove("rotate");
                container.addEventListener(
                    "transitionend",
                    function() {
                        container.classList.remove("active");
                    }, {
                        once: true,
                    }
                );
            }
        });
    });
});
